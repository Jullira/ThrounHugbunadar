/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vinnsla;

/**
 *
 * @author gretabjorg
 */
public class Review {
    private Account user;
    private Hotel hotel;
    private int date;
    private double grade;
    private String reviewText;
    private int reviewResponseDate;
    private String reviewResponse;
}
