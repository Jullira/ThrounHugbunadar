/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vinnsla;

import java.util.ArrayList;

/**
 *
 * @author gretabjorg
 */
public class Account {
    
    public String userName;
    public int hotelID;
    
    private String password;
    private boolean isAdmin;
    
    public void updatePrivilege(ArrayList<String> a) {
    }
      
}
