/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vinnsla;

/**
 *
 * @author gretabjorg
 */
public class Hotel {
    private String name;
    private String address;
    private String city;
    private int areaCode;
    private String description;
    private String pictures;
    private int grade;
    private int starRating;
    private boolean swimmingPool;
    private boolean breakfast;
    private boolean wiFi;
    private boolean handicapFacilities;
    private boolean gym;
    private int hotelID;
    private String roomTableName;
    private String reviewTableName;
}
