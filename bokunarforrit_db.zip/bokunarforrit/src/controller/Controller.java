/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

/**
 *
 * @author gretabjorg
 */
public class Controller {
    // Þetta á ekki að vera void endilega, vorum ekki með neina skilgreiningu í UML-inu okkar
    
    public void searchHotels(){
    }
    
    public void openBooking() {
    }
    
    public void openReview() {
    }
    
    public void openUpdate() {
    }
    
    public void cancelBooking() {
    }
    
    public void newBooking() {
    }
    
    public void deleteReview() {
    }
    
    public void sendToDatabase() {
        
    }
}
